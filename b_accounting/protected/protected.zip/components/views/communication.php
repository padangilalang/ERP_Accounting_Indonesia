<ul class="nav nav-list">
	<li class="nav-header">Communication</li>
</ul>
<?php $this->widget('bootstrap.widgets.BootMenu', array(
		'type'=>'list',
		'items'=>array(
				array('label'=>'SMS','url'=>'#'),
				array('label'=>'Email','url'=>'#'),
				array('label'=>'Chat','url'=>'#'),
				array('label'=>'Click To Call','url'=>'#'),
		),
)); ?>
<br />

