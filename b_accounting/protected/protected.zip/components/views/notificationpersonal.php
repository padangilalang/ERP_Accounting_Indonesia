<div class="art-block">
	<div class="art-block-body">
		<div class="art-blockheader">
			<div class="l"></div>
			<div class="r"></div>
			<h3 class="t">Personal Notification</h3>
		</div>
		<div class="art-blockcontent">
			<div class="art-blockcontent-tl"></div>
			<div class="art-blockcontent-tr"></div>
			<div class="art-blockcontent-bl"></div>
			<div class="art-blockcontent-br"></div>
			<div class="art-blockcontent-tc"></div>
			<div class="art-blockcontent-bc"></div>
			<div class="art-blockcontent-cl"></div>
			<div class="art-blockcontent-cr"></div>
			<div class="art-blockcontent-cc"></div>
			<div class="art-blockcontent-body">
				<div>
					<p>Lorem ipsum dolor sit amet. Nam sit amet sem. Mauris a ante.</p>
				</div>
				<div class="cleared"></div>
			</div>
		</div>
		<div class="cleared"></div>
	</div>
</div>
