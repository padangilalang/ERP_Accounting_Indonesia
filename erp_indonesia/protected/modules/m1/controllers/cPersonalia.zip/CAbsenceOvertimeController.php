<?php

Yii::import('ext.EUserFlash');

class CAbsenceOvertimeController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column1', meaning
	 * using one-column layout. See 'protected/views/layouts/column1.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
				'accessControl', // perform access control for CRUD operations
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
				array('allow', // allow authenticated user to perform 'create' and 'update' actions
						'users'=>array('@'),
				),
				array('deny',  // deny all users
						'users'=>array('*'),
				),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id,$month=0)
	{
		$absence=$this->newAbsence($id);

		$this->render('view',array(
				'model'=>$this->loadModel($id),
				'modelAbsence'=>$absence,
				'month'=>$month,
		));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		Yii::import('application.extensions.alphapager.ApPagination');
			
		$criteria1=new CDbCriteria;
		$alphaPages = new ApPagination('name');
		$alphaPages->applyCondition($criteria1);

		$model=new cPersonalia();

		$criteria=new CDbCriteria;

		if(isset($_GET['cPersonalia'])) {
			$model->attributes=$_GET['cPersonalia'];
			$criteria->compare('name',$model->name,true);
		}

		$criteria->order='updated_date DESC';
		//$criteria->mergeWith($criteria1,false);

		$dataProvider=new CActiveDataProvider('cPersonalia', array(
				'criteria'=>$criteria,
		));


		$this->render('index',array(
				'dataProvider'=>$dataProvider,
				'model'=>$model,
				'alphaPages'=>$alphaPages, // Just like passing e.g. $pages to your view
		));

	}


	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer the ID of the model to be loaded
	 */
	public function loadModel($id)
	{
		$model=cPersonalia::model()->findByPk((int)$id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param CModel the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='cpersonalia-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function newAbsence($id)
	{
		$model=new cPersonaliaAbsence;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['cPersonaliaAbsence']))
		{
			$model->attributes=$_POST['cPersonaliaAbsence'];
			$model->parent_id=cPersonalia::model()->findByPk((int)$id)->absensi_id;
			if($model->save()) {
				Yii::app()->user->setFlash('success','data has been saved successfully');
				$this->refresh();
			}
		}

		return $model;
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdateAbsence($id,$pid)
	{
		$model=$this->loadModelAbsence($id);

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['cPersonaliaAbsence']))
		{
			$model->attributes=$_POST['cPersonaliaAbsence'];
			if ($_POST['cPersonaliaAbsence']['remark']==null)
				$model->remark="Override By User";

			if($model->save()) {
				Yii::app()->user->setFlash('success','data has been saved successfully');
				//EUserFlash::setSuccessMessage('This is a success message.');
				//EUserFlash::setAlertMessage('Hello world');
				$this->redirect(array('view','id'=>cPersonalia::model()->find(array("condition"=>"absensi_id = ".$pid))->id));
			}
		}

		$this->render('updateAbsence',array(
				'model'=>$model,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'index' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteAbsence($id)
	{
		$_mid=$this->loadModelAbsence($id)->parent_id;
		$this->loadModelAbsence($id)->delete();
		//$this->redirect(array('view','id'=>$_mid));
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer the ID of the model to be loaded
	 */
	public function loadModelAbsence($id)
	{
		$model=cPersonaliaAbsence::model()->findByPk((int)$id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionProcess($id,$pid)
	{

		$model1=$this->loadModelAbsence($id);

		$diff = strtotime($model1->cdate) - strtotime(cPersonalia::model()->find(array('condition'=>'absensi_id = ' .$pid))->schedule_basedate);
		$days=round(abs($diff)/60/60/24);
		$pattern=cPersonalia::model()->find(array('condition'=>'absensi_id = ' .$pid))->pattern_id;
		$_parentid=cPersonalia::model()->find(array('condition'=>'absensi_id = ' .$pid))->id;
		$cycle=cSchedule::model()->findByPk($pattern)->daycycle;

		if ($days >= $cycle) {
			$daysc = $days % $cycle;
			$daysd = $daysc + 1;
		} else
			$daysd = $days + 1;
			
		$code=cScheduleDetail::model()->find(array('condition'=>'parent_id = ' .$pattern . ' AND ' .$daysd. ' BETWEEN day_start and day_end'))->code_id;

		$model1->realpattern_id = $code;
		$model1->save();
		Yii::app()->user->setFlash('success','Data berhasil disimpan');

		$this->redirect(array('/cAbsenceOvertime/view','id'=>$_parentid));
	}

	////////////////////////////////////
	public function actionGenerate($pid)
	{
		$model=new FBeginEndDate;

		if (isset($_POST['fBeginEndDate']))
		{
			$model->attributes=$_POST['fBeginEndDate'];

			if($model->validate()) {

				$start = strtotime($model->begindate);
				$end = strtotime($model->enddate);
				$date = $start;
				while($date < $end)
				{

					//#1. Absence base on $pid and $begindate
					$_aid=cPersonalia::model()->find(array('condition'=>'id = ' .$pid))->absensi_id;
					$model1=cPersonaliaAbsence::model()->find(array('condition'=>'parent_id='.$_aid.' AND cdate = "'.date("Y-m-d",$date). '"'));

					if($model1===null) {   //Jika entry Data masih kosong

						$model1=new cPersonaliaAbsence;
						$model1->parent_id=$_aid;
						$model1->cdate=date("Y-m-d",$date);
						$model1->remark="Generated by System";
					}

					//METHOD 1. Read From CTimeBlock2###########################
					$model2=cTimeblock2::model()->find(array('condition'=>'absensi_id='.$_aid.' AND begin_date = "'.date("Ym",$date). '"'));

					if($model2 != null) {   //Method 1. Gunakan Method 1
						$_mdate="c". date("j",$date);
						$code=$model2->$_mdate;
							
					} else {

						$diff = $date - strtotime(cPersonalia::model()->findByPk((int)$pid)->schedule_basedate);
						$days=round(abs($diff)/60/60/24);
						$pattern=cPersonalia::model()->findByPk((int)$pid)->pattern_id;
						$cycle=cSchedule::model()->findByPk($pattern)->daycycle;
							
						if ($days >= $cycle) {
							$daysc = $days % $cycle;
							$daysd = $daysc + 1;
						} else
							$daysd = $days + 1;
							
						$code=cScheduleDetail::model()->find(array('condition'=>'parent_id = ' .$pattern . ' AND ' .$daysd. ' BETWEEN day_start and day_end'))->code_id;
					}

					$model1->realpattern_id = $code;
					$model1->save();
					Yii::app()->user->setFlash('success','Data berhasil disimpan');

					//write your code here
					$date = strtotime("+1 day", $date);

				}

				$this->redirect(array('/cAbsenceOvertime/view','id'=>$pid,'t'=>$date));
					


			}
		}

		$this->render('formAbsence1',array('model'=>$model));
	}


	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionOvertimeFactor($id,$pid)
	{
		$model=$this->loadModelAbsence($id);

		$personmodel=cPersonalia::model()->find(array('condition'=>'absensi_id ='.$pid));

		//1. Hitung OVERTIME_FACTOR

		if ($model->realpattern_id ==17 && $model->daystatus1_id ==8) {
			$_overtimehour=floor((((strtotime($model->out) - strtotime($model->in)) % 604800) % 86400) / 3600);
			$_overtimeminute=abs(round(((((strtotime($model->out) - strtotime($model->in)) % 604800) % 86400) % 3600) / 60, 2));

			$_overtime= $_overtimehour;

			if ($_overtimeminute >= 25)
				$_overtime = $_overtimehour + 0.5;

			if ($_overtime >= 7)
				$_overtime = 7;

		} else {
			$_overtimehour=floor((((strtotime($model->out) - strtotime($model->timeBlock->out) - (30*60)) % 604800) % 86400) / 3600);
			$_overtimeminute=abs(round(((((strtotime($model->out) - strtotime($model->timeBlock->out) - (30*60)) % 604800) % 86400) % 3600) / 60, 2));

			//Standard Value
			$_overtime= $_overtimehour;

			if ($_overtimeminute >= 25) {
				$_overtime = $_overtimehour + 0.5;
				if ($_overtimeminute >= 54)
					$_overtime = $_overtimehour + 1;
			}


			if ($_overtime >= 2)
				$_overtime = 2;
		}

		if ($_overtime >=1) {
			$modelUpdate=cPersonaliaAbsence::model()->updateByPk((int)$id,array('daystatus1_id'=>8,'overtime_factor'=>$_overtime));

			//2. Hitung Uang Lembur
			$modelAbsensePayment=cPersonaliaAbsencePayment::model()->find(array('condition'=>'parent_id ='.$id));

			$_amount = 0;
			if ($model->realpattern_id ==17 && $model->daystatus1_id ==8) {
				if ($personmodel->position->position->parent_id == 177 || $personmodel->position->position->parent_id == 180) {
					$_amount = $_overtime*2*floatval(1/173)*$personmodel->salary->salary;
				} else {
					$_getvalue = cPositionGroupDetail::model()->with('getparent')->find(array('condition'=>'getparent.parent_id = 1 AND position_id ='.$personmodel->position->position->parent_id))->getparent->custom_value1;

					$_amount = floatval($_overtime/7) * $_getvalue;
				}

			} else {
				$_amount = (1.5*floatval(1/173)*$personmodel->salary->salary) + (($_overtime-1)*2*0.005780347*$personmodel->salary->salary);
			}

			//3. Input Amount to Database
			if ($modelAbsensePayment == null) {
				$modelAbsencePaymentNew = new cPersonaliaAbsencePayment;
				$modelAbsencePaymentNew->parent_id = $id;
				$modelAbsencePaymentNew->component_id = 1;
				$modelAbsencePaymentNew->amount=(int)$_amount;
				$modelAbsencePaymentNew->save();
			} else {
				$modelAbsenceUpdate=cPersonaliaAbsencePayment::model()->updateAll(array('amount'=>(int)$_amount),'parent_id ='.$id);
			}
		}
	}


}
