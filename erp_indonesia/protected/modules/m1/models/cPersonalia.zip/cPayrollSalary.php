<?php

/**
 * This is the model class for table "c_personalia_status".
 *
 * The followings are the available columns in table 'c_personalia_status':
 * @property string $id
 * @property string $parent_id
 * @property string $cdate
 * @property integer $salary
 * @property string $remark
 */
class cPayrollSalary extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @return cPayrollSalary the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'c_payroll_salary';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
				array('cdate, salary', 'required'),
				array('salary, valid_id', 'numerical', 'integerOnly'=>true),
				array('parent_id', 'length', 'max'=>11),
				array('remark', 'length', 'max'=>150),
				//array('valid_id', 'boolean'),
				array('cdate', 'safe'),
				// The following rule is used by search().
				// Please remove those attributes that should not be searched.
				array('id, parent_id, cdate, salary, remark', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
				'id' => 'ID',
				'parent_id' => 'Parent',
				'cdate' => 'Date',
				'valid_id' => 'Valid',
				'salary' => 'Salary',
				'remark' => 'Remark',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search($id)
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('parent_id',$id);
		$criteria->compare('cdate',$this->cdate,true);
		$criteria->compare('salary',$this->salary);
		$criteria->compare('remark',$this->remark,true);

		return new CActiveDataProvider(get_class($this), array(
				'criteria'=>$criteria,
		));
	}

	public function behaviors()
	{
		return array(
				'datetimeI18NBehavior' => array('class' => 'ext.DateTimeI18NBehavior'),
				//'defaults'=>array(
				//	'class'=>'ext.decimali18nbehavior.DecimalI18NBehavior',
				//'format'=>'db',
				//),
		);
	}


}