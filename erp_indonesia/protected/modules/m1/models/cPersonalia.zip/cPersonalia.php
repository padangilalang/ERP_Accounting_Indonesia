<?php

/**
 * This is the model class for table "c_personalia".
 *
 * The followings are the available columns in table 'c_personalia':
 * @property integer $id
 * @property string $name
 * @property string $job
 * @property string $birthplace
 * @property double $birthdate
 * @property string $religion
 * @property string $address1
 * @property string $address2
 * @property string $address3
 * @property string $emergency_contact
 * @property string $sickness_hist
 * @property string $blood
 * @property string $height
 * @property string $weight
 * @property string $status
 */
class cPersonalia extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @return cPersonalia the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'c_personalia';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
				array('name, birthplace, address1', 'required'),
				array('id, blood_id, religion_id, pattern_id, statusnikah_id, tanggungan, absensi_id', 'numerical', 'integerOnly'=>true),
				array('birthdate,schedule_basedate', 'type', 'type'=>'date', 'dateFormat'=>'yyyy-MM-dd'),
				array('name, birthplace, address1, address2, address3, emergency_contact, sickness_hist, height, weight, photo', 'length', 'max'=>255),
				array('email, handphone,emergency_number', 'length', 'max'=>50),
				array('handphone', 'ext.BPhoneNumberValidator', 'onlyMobileNumbers' => true),
				// The following rule is used by search().
				// Please remove those attributes that should not be searched.
				array('id, name, birthplace, birthdate, address1, address2, address3, emergency_contact, sickness_hist, height, weight, status', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
				'salary' => array(self::HAS_ONE, 'cPayrollSalary', 'parent_id','condition'=>'valid_id = 1'),
				'structure' => array(self::HAS_ONE, 'cPersonaliaStructure', 'parent_id','condition'=>'structure.valid_id = 1'),
				'position' => array(self::HAS_ONE, 'cPersonaliaPosition', 'parent_id','condition'=>'position.valid_id = 1'),
				'status' => array(self::HAS_ONE, 'cPersonaliaStatus', 'parent_id','condition'=>'status.valid_id = 1'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
				'id' => 'ID',
				'name' => 'Name',
				'birthplace' => 'Birth Place',
				'birthdate' => 'Birth Date',
				'religion_id' => 'Religion',
				'address1' => 'Address',
				'address2' => 'Address2',
				'address3' => 'Address3',
				'email' => 'Email',
				'handphone' => 'Handphone',
				'emergency_contact' => 'Emergency Contact',
				'emergency_number' => 'Emergency Number',
				'sickness_hist' => 'Sickness Hist',
				'blood_id' => 'Blood',
				'height' => 'Height',
				'weight' => 'Weight',
				'statusnikah_id' => 'Status Nikah',
				'tanggungan' => 'Tanggungan',
				'photo' => 'Photo',
				'pattern_id'=>'Pattern',
				'schedule_basedate'=>'Schedule BaseDate',
				'absensi_id'=>'Absensi ID',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('birthplace',$this->birthplace,true);

		return new CActiveDataProvider(get_class($this), array(
				'criteria'=>$criteria,
		));
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function searchActive()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('birthplace',$this->birthplace,true);
		$criteria->compare('birthdate',$this->birthdate);
		$criteria->compare('religion_id',$this->religion_id,true);
		$criteria->compare('address1',$this->address1,true);
		$criteria->compare('address2',$this->address2,true);
		$criteria->compare('address3',$this->address3,true);
		$criteria->compare('emergency_contact',$this->emergency_contact,true);
		$criteria->compare('sickness_hist',$this->sickness_hist,true);
		$criteria->compare('blood_id',$this->blood_id,true);
		$criteria->compare('height',$this->height,true);
		$criteria->compare('weight',$this->weight,true);

		return new CActiveDataProvider(get_class($this), array(
				'criteria'=>$criteria,
		));
	}

	/**
	 * This is invoked before the record is saved.
	 * @return boolean whether the record should be saved.
	 */
	protected function beforeSave()
	{
		if(parent::beforeSave())
		{
			if($this->isNewRecord) {
				$this->created_date=time();
				$this->created_by= yii::app()->user->name;
			} else {
				$this->updated_date=time();
				$this->updated_by= yii::app()->user->name;
			}
			return true;
		}
		else
			return false;
	}


	public function getTopCreated() {

		$criteria=new CDbCriteria;
		$criteria->with=array('status');
		$criteria->compare('status.status_id',1);
		$criteria->limit=10;
		$criteria->order='created_date DESC';

		$models=self::model()->findAll($criteria);

		$returnarray = array();

		foreach ($models as $model) {
			$returnarray[] = array('id' => $model->id, 'label' => $model->name, 'icon'=>'list-alt', 'url' => array('view','id'=>$model->id));
		}

		return $returnarray;
	}

	public function getTopUpdated() {

		$criteria=new CDbCriteria;
		$criteria->with=array('status');
		$criteria->compare('status.status_id',1);
		$criteria->limit=10;
		$criteria->order='updated_date DESC';

		$models=self::model()->findAll($criteria);

		$returnarray = array();

		foreach ($models as $model) {
			$returnarray[] = array('id' => $model->id, 'label' => $model->name, 'icon'=>'list-alt', 'url' => array('view','id'=>$model->id));
		}

		return $returnarray;
	}

	public function getTopRelated($name) {

		//$_related = self::model()->find((int)$id)->account_name;
		$_exp=explode(" ",$name);


		$criteria=new CDbCriteria;
		//$criteria->compare('name',$_related,true,'OR');

		if (isset($_exp[0]))
			$criteria->compare('name',$_exp[0],true,'OR');

		if (isset($_exp[1]))
			$criteria->compare('name',$_exp[1],true,'OR');
			
		$criteria->limit=10;
		$criteria->order='updated_date DESC';

		$models=self::model()->findAll($criteria);

		$returnarray = array();

		foreach ($models as $model) {
			$returnarray[] = array('id' => $model->name, 'label' => $model->name, 'url' => array('view','id'=>$model->id));
		}

		return $returnarray;
	}

	public function behaviors()
	{
		return array(
				'datetimeI18NBehavior' => array('class' => 'ext.DateTimeI18NBehavior'),
				'defaults'=>array(
						'class'=>'ext.decimali18nbehavior.DecimalI18NBehavior',
						//'format'=>'db',
				),
		);
	}



}