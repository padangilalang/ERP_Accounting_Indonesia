<?php

/**
 * This is the model class for table "a_organization".
 *
 * The followings are the available columns in table 'a_organization':
 * @property string $id
 * @property string $parent_id
 * @property integer $sort
 * @property string $name
 */
class cDayCategory extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @return CDayCategory the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'c_daycategory';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
				array('parent_id, sort, name', 'required'),
				array('sort', 'numerical', 'integerOnly'=>true),
				array('parent_id', 'length', 'max'=>20),
				array('name', 'length', 'max'=>15),
				// The following rule is used by search().
				// Please remove those attributes that should not be searched.
				array('id, parent_id, sort, name', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
				'getparent' => array(self::BELONGS_TO, 'CDayCategory', 'parent_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
				'id' => 'ID',
				'parent_id' => 'Parent',
				'sort' => 'Sort',
				'name' => 'Name',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('parent_id',$this->parent_id,true);
		$criteria->compare('sort',$this->sort);
		$criteria->compare('name',$this->name,true);

		return new CActiveDataProvider(get_class($this), array(
				'criteria'=>$criteria,
		));
	}

	/////////////////////////////////////////////////////////////
	/**
	 * Returns the items for the specified type.
	 * @param string item type (e.g. 'PostStatus').
	 * @return array item names indexed by item code. The items are order by their position amounts.
	 * An empty array is returned if the item type does not exist.
	 */

	private static $_items=array();

	public static function items($type)
	{
		if(!isset(self::$_items[$type]))
			self::loadItems($type);
		return self::$_items[$type];
	}

	/**
	 * Loads the lookup items for the specified type from the database.
	 * @param string the item type
	 */
	private static function loadItems($type)
	{
		self::$_items[$type]=array();
		$models=self::model()->findAll(array(
				'condition'=>'parent_id =11',
				'order'=>'sort',
		));
		foreach($models as $model)
			self::$_items[$type][$model->id]=$model->name ." | ".$model->getparent->name;
	}

	/////////////////////////////////////////////
	public function getListed($id) {

		$models=self::model()->findAll(array('condition'=>'parent_id = 0'));
		$mod=self::model()->findByPk((int)$id);


		$_items=array();
		$_items1=array();

		foreach($models as $model)
			$_items[$model->name]=array('label' => $model->name, 'url' => array('index', 'id'=>$model->id));

		$_items1[$model->name]= array('label' =>'Project: '.$mod->name, 'url' => array('index', 'id'=>$model->id),'items'=>$_items);

		return $_items1;
	}


}