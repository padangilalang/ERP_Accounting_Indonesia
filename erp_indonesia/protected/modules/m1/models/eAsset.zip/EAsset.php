<?php

/**
 * This is the model class for table "e_asset".
 *
 * The followings are the available columns in table 'e_asset':
 * @property integer $id
 * @property string $input_date
 * @property integer $periode_date
 * @property string $item
 * @property string $brand
 * @property string $type
 * @property string $serial_number
 * @property integer $category_id
 * @property string $inventory_code
 * @property string $bpb_number
 * @property string $po_number
 * @property string $amount
 * @property integer $supplier_id
 * @property string $warranty
 * @property string $insurance
 * @property string $remark
 * @property string $photo_path
 * @property integer $accesslevel_id
 * @property integer $created_date
 * @property string $created_by
 * @property integer $updated_date
 * @property string $updated_by
 */
class EAsset extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @return EAsset the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'e_asset';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('periode_date, category_id, supplier_id, accesslevel_id, created_date, updated_date', 'numerical', 'integerOnly'=>true),
			array('item, brand, type, serial_number, inventory_code, bpb_number, po_number, warranty, insurance', 'length', 'max'=>100),
			array('amount', 'length', 'max'=>15),
			array('remark, photo_path', 'length', 'max'=>500),
			array('created_by, updated_by', 'length', 'max'=>50),
			array('input_date', 'safe'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, input_date, periode_date, item, brand, type, serial_number, category_id, inventory_code, bpb_number, po_number, amount, supplier_id, warranty, insurance, remark, photo_path, accesslevel_id, created_date, created_by, updated_date, updated_by', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'category'=>array(self::BELONGS_TO, 'EAssetCategory', 'category_id'),		
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'input_date' => 'Input Date',
			'periode_date' => 'Periode Date',
			'item' => 'Item',
			'brand' => 'Brand',
			'type' => 'Type',
			'serial_number' => 'Serial Number',
			'category_id' => 'Category',
			'inventory_code' => 'Inventory Code',
			'bpb_number' => 'Bpb Number',
			'po_number' => 'Po Number',
			'amount' => 'Amount',
			'supplier_id' => 'Supplier',
			'warranty' => 'Warranty',
			'insurance' => 'Insurance',
			'remark' => 'Remark',
			'photo_path' => 'Photo Path',
			'accesslevel_id' => 'Accesslevel',
			'created_date' => 'Created Date',
			'created_by' => 'Created By',
			'updated_date' => 'Updated Date',
			'updated_by' => 'Updated By',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search($id)
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->with=('category');
		$criteria->compare('parent_id',$id);

		$criteria->compare('input_date',$this->input_date,true);
		$criteria->compare('periode_date',$this->periode_date);
		$criteria->compare('item',$this->item,true);
		$criteria->compare('brand',$this->brand,true);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('serial_number',$this->serial_number,true);
		$criteria->compare('inventory_code',$this->inventory_code,true);
		$criteria->compare('bpb_number',$this->bpb_number,true);
		$criteria->compare('po_number',$this->po_number,true);
		$criteria->compare('amount',$this->amount,true);
		$criteria->compare('supplier_id',$this->supplier_id);
		$criteria->compare('warranty',$this->warranty,true);
		$criteria->compare('insurance',$this->insurance,true);
		$criteria->compare('remark',$this->remark,true);
		$criteria->compare('photo_path',$this->photo_path,true);
		$criteria->compare('accesslevel_id',$this->accesslevel_id);
		
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
}